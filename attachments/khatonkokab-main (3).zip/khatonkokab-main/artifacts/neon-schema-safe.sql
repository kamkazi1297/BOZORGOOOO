-- Apex Desk — Neon schema bootstrap (SAFE)
-- Creates every table / column / index the bot needs.
-- Does NOT drop tables, does NOT truncate, does NOT delete rows.
-- Existing data, API keys, positions, journal, settings stay as-is.
-- Safe to run more than once.

BEGIN;

-- ---------------------------------------------------------------------------
-- Bookkeeping so the app will not re-run old migrations that contain DELETE
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS _migrations (
  name TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Auth (Better Auth). Harmless if you never use sign-in.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "user" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "email" TEXT NOT NULL UNIQUE,
  "emailVerified" BOOLEAN NOT NULL,
  "image" TEXT,
  "createdAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS "session" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "expiresAt" TIMESTAMPTZ NOT NULL,
  "token" TEXT NOT NULL UNIQUE,
  "createdAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMPTZ NOT NULL,
  "ipAddress" TEXT,
  "userAgent" TEXT,
  "userId" TEXT NOT NULL REFERENCES "user" ("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "account" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "accountId" TEXT NOT NULL,
  "providerId" TEXT NOT NULL,
  "userId" TEXT NOT NULL REFERENCES "user" ("id") ON DELETE CASCADE,
  "accessToken" TEXT,
  "refreshToken" TEXT,
  "idToken" TEXT,
  "accessTokenExpiresAt" TIMESTAMPTZ,
  "refreshTokenExpiresAt" TIMESTAMPTZ,
  "scope" TEXT,
  "password" TEXT,
  "createdAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS "verification" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "identifier" TEXT NOT NULL,
  "value" TEXT NOT NULL,
  "expiresAt" TIMESTAMPTZ NOT NULL,
  "createdAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
  "updatedAt" TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS "session_userId_idx" ON "session" ("userId");
CREATE INDEX IF NOT EXISTS "account_userId_idx" ON "account" ("userId");
CREATE INDEX IF NOT EXISTS "verification_identifier_idx" ON "verification" ("identifier");

-- ---------------------------------------------------------------------------
-- desk_settings  (single row id = 1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS desk_settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  mode TEXT NOT NULL DEFAULT 'paper',
  venue TEXT NOT NULL DEFAULT 'lighter',
  risk_pct DOUBLE PRECISION NOT NULL DEFAULT 1.0,
  max_positions INTEGER NOT NULL DEFAULT 4,
  min_market_cap_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
  equity_usd DOUBLE PRECISION NOT NULL DEFAULT 10000,
  starting_equity_usd DOUBLE PRECISION NOT NULL DEFAULT 10000,
  live_enabled INTEGER NOT NULL DEFAULT 0,
  bot_enabled INTEGER NOT NULL DEFAULT 1,
  paper_24h INTEGER NOT NULL DEFAULT 1,
  tick_token TEXT NOT NULL DEFAULT 'change-me',
  scan_cursor INTEGER NOT NULL DEFAULT 0,
  last_tick_at TIMESTAMPTZ,
  lighter_api_key TEXT,
  lighter_api_private_key TEXT,
  lighter_account_index INTEGER,
  aster_api_key TEXT,
  aster_api_secret TEXT,
  toobit_api_key TEXT,
  toobit_api_secret TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS last_tick_source TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS operator_pin_hash TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS operator_pin_salt TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS operator_session TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS hyperliquid_private_key TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS hyperliquid_wallet_address TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS lighter_api_key_index INTEGER;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS capital_pct DOUBLE PRECISION NOT NULL DEFAULT 10;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_batch INTEGER NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS tick_lock_at TIMESTAMPTZ;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS journal_seeded INTEGER NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_epoch_ms BIGINT NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_done_5m BIGINT NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_done_15m BIGINT NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_done_1h BIGINT NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_done_4h BIGINT NOT NULL DEFAULT 0;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS universe_venue TEXT;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS max_leverage INTEGER NOT NULL DEFAULT 200;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS stack_lev_count INTEGER NOT NULL DEFAULT 2;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS stack_lev_cap INTEGER NOT NULL DEFAULT 75;
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS scan_cursors TEXT NOT NULL DEFAULT '{}';
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS orphan_fills TEXT NOT NULL DEFAULT '[]';
ALTER TABLE desk_settings ADD COLUMN IF NOT EXISTS tick_lock_id TEXT;

ALTER TABLE desk_settings ALTER COLUMN scan_batch SET DEFAULT 0;
ALTER TABLE desk_settings ALTER COLUMN min_market_cap_usd SET DEFAULT 0;

INSERT INTO desk_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ---------------------------------------------------------------------------
-- universe_assets
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS universe_assets (
  symbol TEXT PRIMARY KEY,
  base TEXT NOT NULL,
  name TEXT NOT NULL,
  market_cap_usd DOUBLE PRECISION NOT NULL,
  volume_24h_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
  max_leverage INTEGER NOT NULL DEFAULT 25,
  listed_lighter INTEGER NOT NULL DEFAULT 1,
  listed_aster INTEGER NOT NULL DEFAULT 1,
  listed_toobit INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE universe_assets ADD COLUMN IF NOT EXISTS venue_symbol TEXT;

-- ---------------------------------------------------------------------------
-- signals
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS signals (
  id SERIAL PRIMARY KEY,
  ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  bar_time BIGINT NOT NULL DEFAULT 0,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  indicator TEXT NOT NULL,
  side TEXT NOT NULL,
  entry DOUBLE PRECISION NOT NULL,
  sl DOUBLE PRECISION NOT NULL,
  tp DOUBLE PRECISION NOT NULL,
  rr DOUBLE PRECISION NOT NULL,
  atr DOUBLE PRECISION,
  reason TEXT,
  taken INTEGER NOT NULL DEFAULT 0,
  skip_reason TEXT
);

CREATE INDEX IF NOT EXISTS signals_ts_idx ON signals (ts DESC);
CREATE INDEX IF NOT EXISTS signals_sym_idx ON signals (symbol, timeframe);

-- Unique index only if no duplicates. Existing rows are never deleted.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'signals_dedupe_idx') THEN
    BEGIN
      CREATE UNIQUE INDEX signals_dedupe_idx
        ON signals (symbol, timeframe, indicator, bar_time);
    EXCEPTION WHEN unique_violation THEN
      RAISE NOTICE 'signals_dedupe_idx skipped — duplicate rows already exist (data kept)';
    END;
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- positions  (journal + open trades)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS positions (
  id SERIAL PRIMARY KEY,
  mode TEXT NOT NULL DEFAULT 'paper',
  venue TEXT NOT NULL DEFAULT 'paper',
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  indicator TEXT NOT NULL,
  side TEXT NOT NULL,
  entry DOUBLE PRECISION NOT NULL,
  sl DOUBLE PRECISION NOT NULL,
  tp DOUBLE PRECISION NOT NULL,
  qty DOUBLE PRECISION NOT NULL DEFAULT 0,
  leverage DOUBLE PRECISION NOT NULL DEFAULT 1,
  notional_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
  risk_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at TIMESTAMPTZ,
  exit_px DOUBLE PRECISION,
  exit_reason TEXT,
  pnl_usd DOUBLE PRECISION,
  pnl_r DOUBLE PRECISION,
  fees_usd DOUBLE PRECISION NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  exchange_order_id TEXT
);

ALTER TABLE positions ADD COLUMN IF NOT EXISTS qty DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS size DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS mode TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS venue TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS notional_usd DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS risk_usd DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS fees_usd DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS exit_px DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS exit_reason TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS pnl_usd DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS pnl_r DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS status TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS exchange_order_id TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS opened_at TIMESTAMPTZ;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS closed_at TIMESTAMPTZ;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS leverage DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS bar_time BIGINT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS orig_sl DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS mae_r DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS mfe_r DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS bars_held INTEGER;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS hold_ms BIGINT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS signal_reason TEXT;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS atr_at_entry DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS be_moved INTEGER NOT NULL DEFAULT 0;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS equity_at_open DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS rr_planned DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS margin_usd DOUBLE PRECISION;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS notes TEXT;

-- Fill NULLs only. Never overwrite a real value.
UPDATE positions SET qty = size WHERE qty IS NULL AND size IS NOT NULL;
UPDATE positions SET size = qty WHERE size IS NULL AND qty IS NOT NULL;
UPDATE positions SET qty = 0 WHERE qty IS NULL;
UPDATE positions SET size = 0 WHERE size IS NULL;
UPDATE positions SET mode = COALESCE(mode, 'paper') WHERE mode IS NULL;
UPDATE positions SET venue = COALESCE(venue, 'paper') WHERE venue IS NULL;
UPDATE positions SET status = COALESCE(status, 'open') WHERE status IS NULL;
UPDATE positions SET fees_usd = COALESCE(fees_usd, 0) WHERE fees_usd IS NULL;
UPDATE positions SET notional_usd = COALESCE(notional_usd, 0) WHERE notional_usd IS NULL;
UPDATE positions SET risk_usd = COALESCE(risk_usd, 0) WHERE risk_usd IS NULL;
UPDATE positions SET leverage = COALESCE(leverage, 1) WHERE leverage IS NULL;
UPDATE positions SET opened_at = COALESCE(opened_at, now()) WHERE opened_at IS NULL;
UPDATE positions SET orig_sl = sl WHERE orig_sl IS NULL AND sl IS NOT NULL;
UPDATE positions
SET rr_planned = abs(tp - entry) / NULLIF(abs(entry - COALESCE(orig_sl, sl)), 0)
WHERE rr_planned IS NULL AND entry IS NOT NULL AND tp IS NOT NULL;
UPDATE positions
SET margin_usd = notional_usd / NULLIF(leverage, 0)
WHERE margin_usd IS NULL AND notional_usd IS NOT NULL AND leverage IS NOT NULL AND leverage <> 0;

ALTER TABLE positions ALTER COLUMN qty SET DEFAULT 0;
ALTER TABLE positions ALTER COLUMN size SET DEFAULT 0;
ALTER TABLE positions ALTER COLUMN fees_usd SET DEFAULT 0;
ALTER TABLE positions ALTER COLUMN notional_usd SET DEFAULT 0;
ALTER TABLE positions ALTER COLUMN risk_usd SET DEFAULT 0;
ALTER TABLE positions ALTER COLUMN leverage SET DEFAULT 1;
ALTER TABLE positions ALTER COLUMN mode SET DEFAULT 'paper';
ALTER TABLE positions ALTER COLUMN venue SET DEFAULT 'paper';
ALTER TABLE positions ALTER COLUMN status SET DEFAULT 'open';
ALTER TABLE positions ALTER COLUMN opened_at SET DEFAULT now();

CREATE INDEX IF NOT EXISTS positions_status_idx ON positions (status, opened_at DESC);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'positions_dedupe_idx') THEN
    BEGIN
      CREATE UNIQUE INDEX positions_dedupe_idx
        ON positions (symbol, timeframe, indicator, bar_time)
        WHERE bar_time IS NOT NULL AND bar_time <> 0;
    EXCEPTION WHEN unique_violation THEN
      RAISE NOTICE 'positions_dedupe_idx skipped — duplicate rows already exist (data kept)';
    END;
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- equity_snapshots
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS equity_snapshots (
  id SERIAL PRIMARY KEY,
  ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  equity_usd DOUBLE PRECISION NOT NULL,
  open_count INTEGER NOT NULL DEFAULT 0,
  mode TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS equity_ts_idx ON equity_snapshots (ts DESC);

-- ---------------------------------------------------------------------------
-- scan_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scan_log (
  id SERIAL PRIMARY KEY,
  ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  scanned INTEGER NOT NULL,
  signals INTEGER NOT NULL,
  opened INTEGER NOT NULL,
  closed INTEGER NOT NULL,
  duration_ms INTEGER NOT NULL,
  note TEXT
);

ALTER TABLE scan_log ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'manual';
CREATE INDEX IF NOT EXISTS scan_log_source_idx ON scan_log (source, ts DESC);

-- ---------------------------------------------------------------------------
-- backtests
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backtests (
  id SERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  indicator TEXT NOT NULL,
  bars INTEGER NOT NULL,
  trades INTEGER NOT NULL,
  wins INTEGER NOT NULL,
  losses INTEGER NOT NULL,
  win_rate DOUBLE PRECISION NOT NULL,
  profit_factor DOUBLE PRECISION NOT NULL,
  expect_r DOUBLE PRECISION NOT NULL,
  net_r DOUBLE PRECISION NOT NULL,
  max_dd_r DOUBLE PRECISION NOT NULL,
  result_json TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- Mark every app migration as applied so the runtime will not re-run the
-- old files that contain DELETE (0010 / 0011). Data stays.
-- ---------------------------------------------------------------------------
INSERT INTO _migrations (name) VALUES
  ('0002_desk.sql'),
  ('0003_cron.sql'),
  ('0004_lock.sql'),
  ('0005_venues.sql'),
  ('0006_sizing.sql'),
  ('0007_scan_all.sql'),
  ('0008_signal_dedupe.sql'),
  ('0009_positions_size.sql'),
  ('0010_position_dedupe.sql'),
  ('0011_signals_dedupe.sql'),
  ('0012_min_cap_setting.sql'),
  ('0013_journal.sql'),
  ('0014_journal_notes.sql'),
  ('0015_scan_done.sql'),
  ('0016_universe_venue.sql'),
  ('0017_max_leverage.sql'),
  ('0018_tick_hardening.sql'),
  ('0021_stack_leverage.sql')
ON CONFLICT (name) DO NOTHING;

COMMIT;
